#!/bin/bash

while :
do
  java -jar application-0.0.1-SNAPSHOT.jar
  sleep 10
done
